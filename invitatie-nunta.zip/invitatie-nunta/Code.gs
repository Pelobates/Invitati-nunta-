/**
 * Cod Google Apps Script pentru salvarea răspunsurilor în Google Sheets.
 * Se lipește în Extensions > Apps Script, în foaia Google Sheets aleasă.
 */

const SHEET_NAME = 'Raspunsuri RSVP';

function doGet() {
  return ContentService
    .createTextOutput('RSVP endpoint activ')
    .setMimeType(ContentService.MimeType.TEXT);
}

function doPost(e) {
  try {
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = spreadsheet.getSheetByName(SHEET_NAME);

    if (!sheet) {
      sheet = spreadsheet.insertSheet(SHEET_NAME);
      sheet.appendRow([
        'Data răspunsului', 'ID invitat', 'Nume și prenume', 'Participă',
        'Prezență', 'Meniu', 'Nume însoțitor', 'Meniu însoțitor',
        'Alergii / cerințe', 'Mesaj'
      ]);
      sheet.setFrozenRows(1);
      sheet.getRange(1, 1, 1, 10).setFontWeight('bold');
    }

    const p = e.parameter || {};
    sheet.appendRow([
      new Date(),
      clean_(p.invitat_id),
      clean_(p.nume),
      clean_(p.participa),
      clean_(p.prezenta),
      clean_(p.meniu),
      clean_(p.insotitor),
      clean_(p.meniu_insotitor),
      clean_(p.alergii),
      clean_(p.mesaj)
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(error) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// Previne interpretarea accidentală ca formulă în Sheets.
function clean_(value) {
  const text = String(value || '').trim();
  return /^[=+\-@]/.test(text) ? "'" + text : text;
}
